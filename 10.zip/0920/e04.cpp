#include <stdio.h>
#include <stdlib.h>
int main()
{
	int a[24] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };
	int i, j, k, l,m,f;
	for (i = 0; i <= 23; i++)
	{
		f=0;
		for (j = 1; j <= 23; j++)
		{
			k = j - 1;
			if (a[k]<a[k + 1])
			{
				f=1;
				l = a[k];
				a[k] = a[k + 1];
				a[k + 1] = l;
			}
		}
		if(f=0)
		{
			break;
		}
	}
	for(m=0;m<=23;m++)
	{
		printf("a[%d]=%d\n", m, a[m]);
	}
	system("pause");
	return 0;
}
