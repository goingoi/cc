#include <stdio.h>
#include <stdlib.h>
ex5()
{
	int a[10][2],b,c,i,j;
	for (i = 0; i < 10; i++)
	{
			printf("��J�s��:");
			scanf("%d", &a[i][0]);
			printf("��J�魫:");
			scanf("%d", &a[i][1]);
	}
	for (j = 0; j < 10; j++)
	{
		printf("�s��%d�魫%d:\n", a[j][0], a[j][1]);
	}
}