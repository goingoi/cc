#include <stdio.h>
#include <stdlib.h>
ex1()