#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
ex11()
{

}