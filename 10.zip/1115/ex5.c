#include <stdio.h>
#include <stdlib.h>
ex5()
{
	char a ;
	a=tolower('A');
	printf("%c", a);
}