#include <stdio.h>
#include <stdlib.h>
ex2()
{
	int a;
	printf(" Please input an integer :");
	scanf("%d",&a);
	printf("num=%d\n",a);
}