#include <stdio.h>
#include <stdlib.h>
#pragma warning(disable:4996)
void ex1();
void ex2();
void ex3();
void ex4();
void ex5();
void ex6();
void ex7();
void ex8();
void ex9();
void ex10();
/*void ex11();
void ex12();
void ex13();
void ex14();
void ex15();
void ex16();
void ex17();
void ex18();
void ex19();
void ex20();
void ex21();
void ex22();*/
int main()
{
	int a, b;
	b = 0;
	printf("1.�m�ߤ@:\n");
	printf("2.�m�ߤG:\n");
	printf("3.�m�ߤT:\n");
	printf("4.�m�ߥ|:\n");
	printf("5.�d�Ҥ@:\n");
	printf("6.�d�ҤG:\n");
	printf("7.�d�ҤT:\n");
	printf("8.�d�ҥ|:\n");
	printf("9.�m�ߤ�:\n");
	printf("10.�d�Ҥ�:\n");
	printf("11.�d�Ҥ�:\n");
	/*printf("12.�m�ߤ�:\n");
	printf("13.�m�ߤC:\n");
	printf("14.�d�ҤC:\n");
	printf("15.�d�ҤK:\n");
	printf("16.�D���j�@�~�@:\n");
	printf("17.�@�~�G:\n");
	printf("18.�@�~�T:\n");
	printf("19.�D���j�@�~�|:\n");
	printf("20.�@�~��:\n");
	printf("21.���j�@�~�@:\n");
	printf("22.���j�@�~�|:\n");*/
	do
	{
		printf("��J�D��:");
		scanf("%d", &a);
		switch (a)
		{
		case 1:
			ex1();
			break;
		case 2:
			ex2();
			break;
		case 3:
			ex3();
			break;
		case 4:
			ex4();
			break;
		case 5:
			ex5();
			break;
		case 6:
			ex6();
			break;
		case 7:
			ex7();
			break;
		case 8:
			ex8();
			break;
		case 9:
			ex9();
			break;
		case 10:
			ex10();
			break;
			/*case 11:
			ex11();
			break;
			case 12:
			ex12();
			break;
			case 13:
			ex13();
			break;
			case 14:
			ex14();
			break;
			case 15:
			ex15();
			break;
			case 16:
			ex16();
			break;
			case 17:
			ex17();
			break;
			case 18:
			ex18();
			break;
			case 19:
			ex19();
			break;
			case 20:
			ex20();
			break;
			case 21:
			ex21();
			break;
			case 22:
			ex22();
			break;*/
		default:
			printf("��J���~\n");
			break;
		}
	} while (b == 0);
	system("pause");
	return 0;
}