#include <stdio.h>
#include <stdlib.h>
ex3()
{
	double d;
	double *p = &d;
	double **pp = &p;
	printf("�п�J�@float��:");
	scanf("%1f",&d);
	printf("d=%.2f,*p=%.2f,**pp=%.2f\n",d,*p,*pp);
}