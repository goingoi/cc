#include <stdio.h>
#include <stdlib.h>
ex2()
{
	int a = 100;
	int *p = &a;
	int **pp =&p;
	printf("a=%d,*p=%d,and**PP=%d\n", a, *p, **pp);
}