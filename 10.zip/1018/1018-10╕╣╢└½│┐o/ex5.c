#include <stdio.h>
#include <stdlib.h>
ex5()
{
	int i,j;
	char *a[13] = { "ab", "cd", "ef", "gh", "ig", "kl", "mn", "op", "qr", "st", "uv", "wx", "yz"};
	for (i = 0; i < 13; i++)
	{
		for (j = 0; j < 2; j++)
		{
			printf("%c\n", *(*(a + i) + j));
		}
	}
		
}
