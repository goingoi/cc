#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
//97 122 65 96
char char_convart();
void main()
{
		printf("�п�J�^��:\n");
		char ch;
		scanf("%c", &ch);
		char chh=char_convart(ch);
		printf("%c", chh);
}
char char_convart(chh)
{
	if (chh >= 65 && chh <= 96)
	{
		chh += 32;
	}
	else if (chh <= 122 && chh >= 97)
	{
		chh -= 32;
	}
	return chh;
	system("pause");
}
