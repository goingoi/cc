#include <stdio.h>
#include <stdlib.h>

void ex1();
void ex2();
void ex3();
void ex4();
void ex5();
void ex6();
void ex7();
void ex8();
void ex9();
void ex10();
void ex11();
int main()
{
	int a, b;
	b = 0;
	printf("1.�Ҹդ@:\n");
	printf("2.�ҸդG:\n");
	printf("3.�ҸդT:\n");
	printf("4.�Ҹե|:\n");
	printf("5.�Ҹդ�:\n");
	printf("6.�Ҹդ�:\n");
	printf("7.�ҸդC:\n");
	printf("8.�ҸդK:\n");
	printf("10.�@�~�@\n");

	do
	{
		printf("��J�D��:");
		scanf("%d", &a);
		while (getchar() != '\n')
			continue;
		switch (a)
		{
		case 1:
			ex1();
			break;
		case 2:
			ex2();
			break;
		case 3:
			ex3();
			break;
		case 4:
			ex4();
			break;
		case 5:
			ex5();
			break;
		case 6:
			ex6();
			break;
		case 7:
			ex7();
			break;
		case 8:
			ex8();
			break;
		case 9:
			ex9();
			break;
		case 10:
			ex10();
			break;
		case 11:
			ex11();
			break;
		default:
			printf("��J���~\n");
			break;
		}
	} while (b == 0);
	system("pause");
}