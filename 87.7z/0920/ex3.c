#include <stdio.h>
#include <stdlib.h>
ex3()
{
	int A[2][3][4] = { 1,2 ,3 ,4 ,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24};
	int i,j,k, min, max;
	min = max = A[0][0][0];
	for (i = 0; i<2; i++)
	{
		for (j = 0; j < 3; j++)
		{
			for (k = 0; k < 4; k++)
			{
				if (A[i][j][k]>max)
					max = A[i][j][k];
				if (A[i][j][k]<min)
					min = A[i][j][k];
			}
		}
	}
	printf("�̤j��:%d\n", max);
	printf("�̤p��:%d\n", min);
}
