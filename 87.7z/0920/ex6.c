#include <stdio.h>
#include <stdlib.h>
ex6()
{
	int a[24] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };
	int i, j, k, l;
	l = a[0];
	for (i = 0; i <= 22; i++)
	{
		for (j = 1; j <= 22; j++)
		{
			k = j - 1;
			if (a[k]>a[k + 1])
			{
				l = a[k];
				a[k] = a[k + 1];
				a[k + 1] = l;
			}
		}
		printf("a[%d]=%d\n", i, a[i]);
	}
	system("pause");
	return 0;
}
