#include <stdio.h>
#include <stdlib.h>
ex4()
{
	int a1 = 100, *ptri, a2 = 3, *ptrf;
	ptri = &a2; 
	ptrf = &a1;
	printf("sizeof(a1)=%d\n", sizeof(a1));
	printf("sizeof(a2)=%d\n", sizeof(a2));
	printf("a1=%d,*ptri=%d\n", a1, *ptri);
	printf("a2=%.1f,*ptrf=%.1f\n", a2, *ptrf);
}