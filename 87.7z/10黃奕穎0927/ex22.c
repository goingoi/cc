#include<stdio.h>
#include<stdlib.h>
int Fibonacci(int n);
int i, n, f;
ex22()
{
	printf("�п�J�Q��X�X�ӶO���\n");
	scanf("%d", &n);
	f = Fibonacci(n);
	printf("%d\n", f);
}
int Fibonacci(int n)
{
	f = n;
	if (n >= 2)f = Fibonacci(n - 2) + Fibonacci(n - 1);
	return f;
}