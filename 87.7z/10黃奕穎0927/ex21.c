#include <stdio.h>
#include <stdlib.h>
int factorial2(int);
int a, b, c, d,e;
ex21()
{
	printf("��J��ӼƦr:");
	scanf("%d%d",&a,&b);
	if (a>b)e =d = a;
	else e = d = b;
	c = factorial2(d);
	printf("�̤j���]�Ƭ�:%d", c);
}
int factorial2(int d)
{
	if (d>=0)
	{
		e=factorial2
	}
	return e;
}
