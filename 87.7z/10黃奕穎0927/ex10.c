#include <stdio.h>
#include <stdlib.h>
int number;        
void output2(void);  
ex10()
{
	printf("Please enter a number : ");
	scanf("%d", &number);
	output2();
	system("PAUSE");
	return 0;
}
void output2(void)
{
	printf("Number is %d\n", number);
}
