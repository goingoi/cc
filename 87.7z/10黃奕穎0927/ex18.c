#include <stdio.h>
#include <stdlib.h>
int mex();
int mex1();
int a = 4, a1 = 5, a2 = 6;
ex18()
{

	mex();
	mex1();
	system("pause");
}
int mex()
{
	if (a>a1 && a>a2)
	{
		printf("�̤j��%d\n", a);
	}
	if (a1>a&&a1>a2)
	{
		printf("�̤j��%d\n", a1);
	}
	if (a2>a&&a2>a1)
	{
		printf("�̤j��%d\n", a2);
	}

}
int mex1()
{
	if (a<a1&&a<a2)
	{
		printf("�̤p��%d\n", a);
	}
	if (a1<a&&a1<a2)
	{
		printf("�̤p��%d\n", a1);
	}
	if (a2<a&&a2<a1)
	{
		printf("�̤p��%d\n", a2);
	}
}