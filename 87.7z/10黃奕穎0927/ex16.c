#include <stdio.h>
#include <stdlib.h>
int going();
int a, b, c, d;
ex16()
{
	printf("�п�J��ӼƦr:");
	scanf("%d%d", &a, &b);
	going();
	printf("�̤j���]�Ƭ�:%d\n", d);
}
int going()
{
	for (c = 1; c < 10000; c++)
	{
		if (a%c == 0 && b%c == 0)
		{
			d = c;
		}
		if (c > a || c > b)
		{
			break;
		}
	}
	return d;
}