#include <stdio.h>
#include <stdlib.h>
void calculate();
ex2()
{
	calculate();
}
void calculate()
{
	int a;
	printf("��J���:");
	scanf("%d", &a);
	if (a>=60)
	{
		printf("pass\n");
	}
	else
	{
		printf("down\n");
	}
}