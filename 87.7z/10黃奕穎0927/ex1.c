#include <stdio.h>
#include <stdlib.h>
void dash();
ex1()
{
	dash();
	printf("\n");
}
void dash()
{
	int i;
	for (i = 0; i < 50; i++)
	{
		printf("_");
	}
}