#include <stdio.h>
#include <stdlib.h>
void init1();
void getans1();
void compare1();
int a, b, c = 1;
ex17()
{
	init1();
	getans1();
	compare1();
}
void init1()
{
	printf("��J�@�ӼƦr");
	scanf("%d",&b);
}
void getans1()
{
	printf("�q�@�ӼƦr:");
	scanf("%d", &a);
}
void compare1()
{
	if (a == b)
	{
		printf("�q��F\n");
	}
	else
	{
		printf("�q���F\n");
	}
}