#include <stdio.h>
#include <stdlib.h>
int a;
int goin2();
ex13()
{
	int b;
	b = goin2();
	printf("%d\n", b);
}
goin2()
{
	a = 8;
	return a;
}