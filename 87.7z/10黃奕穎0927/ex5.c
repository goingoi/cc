#include <stdio.h>
#include <stdlib.h>
ex5()
{
	int i, a, b;
	for (i = 1; i <= 10; i++)
	{
		printf("�п�J a �M b: ");
		scanf("%d %d", &a, &b);
		if (b == 0)
			return;
		else
			printf("%d/%d=%d\n", a, b, a / b);
		printf("for �j��]�F %d ��\n\n", i);
	}
}