#include <stdio.h>
#include <stdlib.h>
void input(void);
void output(void);
ex11()
{
	printf("���{���b���ե����ܼ�\n");
	input();
	output();
	system("PAUSE");
	return 0;
}
int array[5];
void input(void)
{
	int index;
	for (index = 0; index < 5; index++)
	{
		printf("�п�J #%d ���: ",index + 1);
		scanf("%d", &array[index]);
	}
}
void output(void)
{
	int index;
	printf("\n");
	for (index = 0; index < 5; index++)
		printf("array[%d] is %d\n", index,
		array[index]);
}
