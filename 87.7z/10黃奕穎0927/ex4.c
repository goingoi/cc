#include <stdio.h>
#include <stdlib.h>
int bitch();
ex4()
{
	int a;
	a=bitch();
	printf("�����%d\n", a);
}
int bitch()
{
	int a;
	printf("��J�@�Ӽ�");
	scanf("%d", &a);
	if (a < 0) a = -a;
	return a;
}