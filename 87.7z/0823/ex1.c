#include <stdio.h>
#include <stdlib.h>
ex1()
{
	printf("Hello C!\n");
	printf("Hello World!\n");
}	