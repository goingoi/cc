#include <stdio.h>
#include <stdlib.h>
hw1()
{
	printf("Hello Every One,Welcome to the C World!\n");
}