#include <stdio.h>
#include <stdlib.h>
hw3()
{

}