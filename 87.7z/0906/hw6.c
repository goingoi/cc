#include <stdio.h>
#include <stdlib.h>
hw6()
{

}